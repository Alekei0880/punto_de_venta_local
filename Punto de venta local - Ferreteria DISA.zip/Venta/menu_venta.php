<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <?php
    // Inicia la sesión
    session_start();

    // Verifica si el usuario ha iniciado sesión
    if (!isset($_SESSION['id_empleado'])) {
        // Si no ha iniciado sesión, redirige a la página de inicio de sesión
        header("Location: ../login.php");
        exit();
    }
    ?>
    
    <link rel="stylesheet" href="menu_venta.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>

    <?php
    $usuario = "root";
    $contrasena = "";
    $servidor = "localhost";
    $basededatos = "ferreteria_disa";

    $conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se ha podido conectar al servidor de Base de datos");

    $db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la base de datos");

    $consulta = "SELECT * FROM producto";

    $resultado = mysqli_query($conexion, $consulta) or die ("Algo ha ido mal en la consulta a la base de datos");
    ?>

    <header>
        <div class="welcome">
            <span class="welcome-text">Bienvenido <?php echo $_SESSION['nombre_empleado'] ?></span>
            <img src="../disa png colibri.png" alt="Logo DISA" id="logo">
            <input type="submit" name="cerrar" value="Cerrar sesión" onclick="location.href='../logout.php'">
        </div>
    </header>


    <nav>
        <ul>
        <li><a href="../">Producto</a></li>
            <li><a >Venta</a></li>
            <li><a href="menu_reporte.php">Reporte</a></li>
        </ul>
    </nav>

    <div name= "List_products">
        <!-- Lado izquierdo: Lista de productos -->
        <div style="width: 45%;">
        <h2>Productos Añadidos</h2>
            <table id="tablaProductos">
                <thead>
                    <tr>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Cantidad</th>
                        <th>Precio</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody id="listaProductos">
                    <!-- Aquí se mostrarán los productos agregados -->
                </tbody>
            </table>
            <br><input type="submit" name = "venta" value= "Realizar venta" onclick="realizarVenta()">

    </div>

    <div name= "form_venta">
            <h2>Formulario de Venta</h2>
            <label for="buscarProducto">Buscar Producto:</label>
            <input type="text" id="buscarProducto" name="buscarProducto" oninput="buscarProducto()">
            <div id="resultadosBusqueda"></div>

            <label for="cantidad">Cantidad:</label>
            <input type="number" id="cantidad" name="cantidad" min="1" value="1">

     </div>

    <script>
        // Variables para almacenar los productos vendidos
        let productosVendidos = [];

        // Función para buscar productos en tiempo real
        function buscarProducto() {
            const buscarTexto = $("#buscarProducto").val();

            // Realizar búsqueda solo si hay al menos 3 caracteres
            if (buscarTexto.length >= 1) {
                // Enviar datos al servidor mediante AJAX para realizar la búsqueda
                $.ajax({
                    url: 'buscar_producto.php', // Ruta al script PHP que realiza la búsqueda
                    method: 'POST',
                    data: { buscarTexto: buscarTexto },
                    success: function(response) {
                        // Mostrar los resultados de la búsqueda
                        $("#resultadosBusqueda").html(response);
                    },
                    error: function() {
                        alert('Error al realizar la búsqueda. Inténtalo de nuevo.');
                    }
                });
            } 
            else {
                // Limpiar resultados de búsqueda si el texto es corto
                $("#resultadosBusqueda").empty();
            }
        }

        // Función para seleccionar un producto de la búsqueda y cargarlo en el select
        function seleccionarProducto(idProducto, nombreProducto, precioVenta) {
            // Modifica esta línea para agregar correctamente el producto al array
            $("#listaProductos").append(`
                <tr>
                    <td>${idProducto}</td>
                    <td>${nombreProducto}</td>
                    <td>${precioVenta}</td>
                    <td><input type="number" value="1"></td>
                    <td><button onclick="eliminarProducto(${idProducto})">Eliminar</button></td>
                </tr>
            `);

            const cantidad = $("#cantidad").val();

            // Validar que la cantidad sea un número positivo
            if (cantidad > 0) {
                productosVendidos.push({ idProducto, nombreProducto, cantidad, precioVenta });
                actualizarListaProductos();
            } else {
                alert("La cantidad debe ser un número positivo.");
            }

            // Limpiar campo de búsqueda y resultados
            $("#buscarProducto").val('');
            $("#resultadosBusqueda").empty();
        }

        function eliminarProducto(idProducto) {
            // Filtrar el array para excluir el producto con el ID especificado
            productosVendidos = productosVendidos.filter(item => item.idProducto !== idProducto);
            actualizarListaProductos();
        }

        // Función para actualizar la lista de productos vendidos en el formulario
        function actualizarListaProductos() {
            $("#listaProductos").empty();
            let totalVenta = 0;

            productosVendidos.forEach(item => {
                const totalProducto = item.cantidad * item.precioVenta;
                totalVenta += totalProducto;

                $("#listaProductos").append(`
                    <tr>
                        <td>${item.idProducto}</td>
                        <td>${item.nombreProducto}</td>
                        <td>${item.cantidad}</td>
                        <td>$${item.precioVenta}</td>
                        <td>$${totalProducto}</td>
                    </tr>
                `);
            });

            // Agregar fila de total de venta
            $("#listaProductos").append(`
                <tr>
                    <td colspan="4" ;">Total:</td>
                    <td>$${totalVenta}</td>
                </tr>
            `);
        }


        // Función para realizar la venta (enviar datos al servidor)
        function realizarVenta() {
            // Validar que haya al menos un producto para vender
            if (productosVendidos.length === 0) {
                alert("Agrega al menos un producto antes de realizar la venta.");
                return;
            }

            // Convertir el array de productosVendidos a formato JSON
            const productosJSON = JSON.stringify(productosVendidos);

            // Enviar datos al servidor mediante AJAX
            $.ajax({
                url: 'procesar_venta.php', // Ruta al script PHP que procesa la venta
                method: 'POST',
                data: { productos: productosJSON },
                success: function(response) {
                    // Manejar la respuesta del servidor (puede ser una confirmación o un mensaje de error)
                    alert(response);

                    // Reiniciar el formulario
                    productosVendidos = [];
                    $("#ventaForm")[0].reset();
                    actualizarListaProductos();
                },
                error: function() {
                    alert('Error al procesar la venta. Inténtalo de nuevo.');
                }
            });
        }
    </script>

    <footer>
        <!-- Contenido del pie de página -->
    </footer>

</body>

</html>
