<!DOCTYPE html>
<html lang="en">

<head>
    <?php
    session_start();
    if (!isset($_SESSION['id_empleado'])) {
        header("Location: ../login.php");
        exit();
    }
    ?>

    <meta charset="UTF-8">
    <title>Ferreteria DISA</title>
    <link rel="stylesheet" href="style_registra.css">
</head>

<body>

<header>
        <div class="welcome">
            <span class="welcome-text">Bienvenido <?php echo $_SESSION['nombre_empleado'] ?></span>
            <img src="../disa png colibri.png" alt="Logo DISA" id="logo">
            <input type="submit" name="cerrar" value="Cerrar sesión" onclick="location.href='../logout.php'">
        </div>
    </header>


    <nav>
        <ul>
        <li><a href="../">Producto</a></li>
            <li><a >Venta</a></li>
        </ul>
    </nav>

    

    <?php
    $usuario = "root";
    $password = "";
    $servidor = "localhost";
    $basededatos = "ferreteria_disa";

    $conexion = mysqli_connect($servidor, $usuario, $password) or die("No se ha podido conectar al servidor de Base de datos");
    $db = mysqli_select_db($conexion, $basededatos) or die("Upps! Pues va a ser que no se ha podido conectar a la base de datos");

    if (isset($_POST["insert"])) {
        $codigo = $_POST["Id_producto"];
        $nombre = $_POST["Nombre_pr"];
        $precio_original = $_POST["Precio"];
        $cantidad = $_POST["Cantidad"];
        $ubicacion = $_POST["Ubicacion"];

        $precio = $precio_original + ($precio_original * 0.3) + ($precio_original * 0.16);

        $insertar = "INSERT INTO producto (Id_producto, Nombre_pr, Precio_dis, Precio, Cantidad, Ubicacion) VALUES ('$codigo', '$nombre', '$precio_original', '$precio', '$cantidad', '$ubicacion')";
        $ejecutar = mysqli_query($conexion, $insertar);

        if ($ejecutar) {
            
        } else {
            echo "Error: " . $insertar . "<br>" . mysqli_error($conexion);
        }
    }
    ?>

    <form method="POST" action="">
        <label>Código del producto:<br></label>
        <input type="text" name="Id_producto" placeholder="Escriba el código" required><br />

        <label>Nombre:<br></label>
        <input type="text" name="Nombre_pr" placeholder="Escriba el nombre" required><br />

        <label>Ubicación:<br></label>
        <input type="text" name="Ubicacion" placeholder="Escriba la ubicación" required><br />

        <label>Precio original:<br></label>
        <input type="number" name="Precio" placeholder="Escriba el precio original" required><br />

        <label>Cantidad:<br></label>
        <input type="number" name="Cantidad" placeholder="Escriba la cantidad" required><br />

        <br />
        <input type="submit" name="insert" value="Guardar">
    </form>

    <?php
    mysqli_close($conexion);
    ?>
</body>

</html>
