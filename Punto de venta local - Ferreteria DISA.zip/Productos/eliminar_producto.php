<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Eliminar productos</title>
    <link rel="stylesheet" href="style_eliminar.css">
</head>

<body>


    <?php
    // Inicia la sesión
        session_start();

        // Verifica si el usuario ha iniciado sesión
        if (!isset($_SESSION['id_empleado'])) {
            // Si no ha iniciado sesión, redirige a la página de inicio de sesión
            header("Location: ../login.php");
            exit();
        }
        ?>

    <div>
        <input type="submit" name="volver" value="Volver" onclick="location.href='menu_productos.php'">
    </div>


    <?php

        $conexion = mysqli_connect("localhost", "root", "", "ferreteria_disa") or die ("No se ha podido conectar al servidor de Base de datos");
        $conexion -> set_charset("utf8");

        $codEliminar = mysqli_real_escape_string($conexion, $_REQUEST['codEliminar']);
        $registro = mysqli_query($conexion, "SELECT * FROM producto WHERE Id_producto = '$codEliminar'") or die ("Problemas en la consulta: ".mysqli_error($conexion));

        if ($reg = mysqli_fetch_array($registro)){
            mysqli_query($conexion, "DELETE FROM producto WHERE Id_producto = '$codEliminar'") or die ("Problemas en la consulta: ".mysqli_error($conexion));

            header("Location: ../index.php");
        }
        
        
        

        mysqli_close($conexion);
    
    ?>

</body>

</html>