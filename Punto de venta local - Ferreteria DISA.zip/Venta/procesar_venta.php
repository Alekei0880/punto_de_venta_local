<?php
// Inicia la sesión
session_start();

// Verifica si el usuario ha iniciado sesión
if (!isset($_SESSION['id_empleado'])) {
    // Si no ha iniciado sesión, redirige a la página de inicio de sesión
    header("Location: ../login.php");
    exit();
}

// procesar_venta.php

// Verificar si se recibieron datos por POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Obtener los datos de productos desde la solicitud
    $productosJSON = $_POST['productos'];

    // Decodificar el JSON a un array de PHP
    $productosVendidos = json_decode($productosJSON, true);

    // Realizar la conexión a la base de datos (ajusta las credenciales según tu configuración)
    $conexion = new mysqli("localhost", "root", "", "ferreteria_disa");

    // Verificar la conexión
    if ($conexion->connect_error) {
        die("Error de conexión a la base de datos: " . $conexion->connect_error);
    }

    // Iniciar una transacción para asegurar la consistencia de la base de datos
    $conexion->begin_transaction();

    try {
        // Obtener el ID del empleado desde la sesión (reemplaza con tu lógica de sesión)
        $idEmpleado = obtenerIdEmpleadoDesdeSesion(); // Implementa esta función según tus necesidades

        // Verificar el stock antes de realizar la venta
        foreach ($productosVendidos as $producto) {
            $idProducto = $producto['idProducto'];
            $cantidad = $producto['cantidad'];

            // Verificar si la cantidad es menor o igual a 0
            if ($cantidad <= 0) {
                echo "Error: El producto $idProducto no se puede vender, cantidad no válida.";
                exit();
            }

            // Verificar el stock disponible
            $queryStock = "SELECT Cantidad FROM producto WHERE Id_producto = '$idProducto'";
            $resultStock = $conexion->query($queryStock);

            if ($resultStock) {
                $stockDisponible = $resultStock->fetch_assoc()['Cantidad'];

                if ($stockDisponible < $cantidad) {
                    echo "Error: El producto $idProducto no tiene suficiente stock.";
                    exit();
                }
            } else {
                echo "Error al verificar el stock del producto $idProducto: " . $conexion->error;
                exit();
            }
        }

        // Registrar la venta en la tabla 'venta'
        foreach ($productosVendidos as $producto) {
            $idProducto = $producto['idProducto'];
            $cantidad = $producto['cantidad'];
            $fechaHora = date('Y-m-d H:i:s'); // Obtener la fecha y hora actual

            $query = "INSERT INTO venta (Id_em_1, Id_producto_1, Cantidad, Fecha_hora)
                      VALUES ('$idEmpleado', '$idProducto', '$cantidad', '$fechaHora')";
            
            $conexion->query($query);

            // Actualizar la cantidad en la tabla 'producto'
            $queryUpdate = "UPDATE producto SET Cantidad = Cantidad - $cantidad WHERE Id_producto = '$idProducto'";
            $conexion->query($queryUpdate);
        }

        // Confirmar la transacción
        $conexion->commit();

        // Enviar una respuesta al cliente
        echo "Venta registrada con éxito.";
    } catch (Exception $e) {
        // Si hay un error, deshacer la transacción
        $conexion->rollback();
        echo "Error al procesar la venta: " . $e->getMessage();
    } finally {
        // Cerrar la conexión a la base de datos
        $conexion->close();
    }
} else {
    // Si la solicitud no es por POST, enviar un mensaje de error
    echo "Error en la solicitud.";
}

// Función para obtener el ID del empleado desde la sesión
function obtenerIdEmpleadoDesdeSesion() {
    // Verificar si la clave 'id_empleado' está presente en la sesión
    if (isset($_SESSION['id_empleado'])) {
        // Devolver el valor almacenado en la sesión
        return $_SESSION['id_empleado'];
    } else {
        // Si la clave no está presente, puedes manejar el caso según tus necesidades
        // Por ejemplo, podrías redirigir al usuario a la página de inicio de sesión
        header("Location: ../login.php");
        exit();
    }
}
?>
