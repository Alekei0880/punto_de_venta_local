    <?php
        require('conexion.php');
        $sql = "SELECT Id_producto, Nombre_pr FROM producto WHERE Cantidad < 3";
        $stmt = $conexion->prepare($sql);
        $result = $stmt->execute();
        $rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        foreach($rows as $row){
            print $row['Id_producto'] . ";" . $row['Nombre_pr'] . ";". "    ". "\n";
        }
        ?>