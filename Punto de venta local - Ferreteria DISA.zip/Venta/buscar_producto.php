<?php
// Configuración de conexión a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ferreteria_disa";


// Recibir datos de búsqueda del formulario
$buscarTexto = $_POST['buscarTexto'];

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Realizar búsqueda en la tabla de productos
$sql = "SELECT Id_producto, Nombre_pr, Precio FROM producto WHERE Nombre_pr LIKE '%$buscarTexto%' OR Id_producto LIKE '%$buscarTexto%'";
$result = $conn->query($sql);

// Mostrar resultados de la búsqueda
// Mostrar resultados de la búsqueda
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div onclick='seleccionarProducto(\"{$row['Id_producto']}\", \"{$row['Nombre_pr']}\", \"{$row['Precio']}\")'>{$row['Id_producto']} - {$row['Nombre_pr']} - $ {$row['Precio']} </div> <br>";
    }
} else {
    echo "No se encontraron resultados.";
}


// Cerrar la conexión
$conn->close();
?>
