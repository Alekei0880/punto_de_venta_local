<?php
// Inicia la sesión
session_start();

// Verifica si el formulario de inicio de sesión ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Verifica si las variables POST están definidas
    if (isset($_POST['usuario']) && isset($_POST['contrasena'])) {
        // Conecta a la base de datos (cambia estos valores según tu configuración)
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "ferreteria_disa";

        $conn = new mysqli($servername, $username, $password, $dbname);

        // Verifica la conexión
        if ($conn->connect_error) {
            die("Conexión fallida: " . $conn->connect_error);
        }

        // Obtiene el usuario y la contraseña del formulario
        $usuario = $_POST['usuario'];
        $contrasena = $_POST['contrasena'];

        // Consulta SQL para verificar las credenciales
        $sql = "SELECT * FROM empleado WHERE Usuario='$usuario' AND Contraseña='$contrasena'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            // Inicio de sesión exitoso
            $_SESSION['id_empleado'] = $row['Id_em'];
            $_SESSION['nombre_empleado'] = $row['Nombre_em'];
            header("Location: Venta/menu_venta.php"); // Redirige a la página principal
        } else {
            $error = "Credenciales incorrectas"; // Muestra un mensaje de error si falla el inicio de sesión
        }

        // Cierra la conexión a la base de datos
        $conn->close();
    } else {
        $error = "Por favor, completa ambos campos"; // Mensaje de error si las variables POST no están definidas
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="style_login.css">
</head>
<body>
    <div class="login-container">
        <h2>Iniciar Sesión</h2>
        <?php if(isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="post" action="">
            Usuario: <input type="text" name="usuario" required><br>
            Contraseña: <input type="password" name="contrasena" required><br>
            <input type="submit" value="Iniciar Sesión">
            <input type="submit" value="Volver" onclick="location.href='../index.php'">
        </form>
    </div>
</body>
</html>
