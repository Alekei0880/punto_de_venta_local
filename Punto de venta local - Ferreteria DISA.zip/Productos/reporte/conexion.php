<?php

    $conexion = null;
    $servidor = "localhost";
    $basededatos = "ferreteria_disa";
    $usuario = "root";
    $contrasena = "";

    try{
        $conexion = new PDO("mysql:host=$servidor;dbname=$basededatos", $usuario, $contrasena);
    }catch(PDOException $e){
        echo "Conexion fallida: " . $e->getMessage();
    }

    return $conexion;
?>