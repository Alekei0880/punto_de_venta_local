<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <?php
    // Inicia la sesión
    session_start();

    // Verifica si el usuario ha iniciado sesión
    if (!isset($_SESSION['id_empleado'])) {
        // Si no ha iniciado sesión, redirige a la página de inicio de sesión
        header("Location: ../login.php");
        exit();
    }
    ?>
    
    <link rel="stylesheet" href="menu_reporte.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
</head>

<body>

    <?php
    $usuario = "root";
    $contrasena = "";
    $servidor = "localhost";
    $basededatos = "ferreteria_disa";

    $conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se ha podido conectar al servidor de Base de datos");

    $db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la base de datos");

    $consulta = "SELECT * FROM producto";

    $resultado = mysqli_query($conexion, $consulta) or die ("Algo ha ido mal en la consulta a la base de datos");
    ?>

    <header>
        <div class="welcome">
            <span class="welcome-text">Bienvenido <?php echo $_SESSION['nombre_empleado'] ?></span>
            <img src="../disa png colibri.png" alt="Logo DISA" id="logo">
            <input type="submit" name="cerrar" value="Cerrar sesión" onclick="location.href='../logout.php'">
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="../">Producto</a></li>
            <li><a href="menu_venta.php" class="active">Venta</a></li>
        </ul>
    </nav>

    <!-- ... Código existente ... -->

    <div class="main-content">
        <br>
        <h3>Reporte de Ventas</h3>

        <!-- Formulario con menú desplegable -->
        <form action="#" method="POST" name="form_reporte" id="form_reporte">
            <label for="tipo_reporte">Seleccionar reporte:</label>
            <select name="tipo_reporte" id="tipo_reporte">
                <option value="dia">Venta del día</option>
                <option value="ultimos7dias">Últimos 7 días</option>
                <option value="ultimoMes">Último mes</option>
                <option value="ultimoAnio">Último año</option>
            </select><br><br>
            <input type="button" value="Generar Reporte" onclick="generarReporte()">
            <input type="submit" name="faltante" value="Imprimir" onclick="abrirNuevaPestana()">
        </form>

        <!-- Contenedor para la tabla de reporte -->
        <div id="tablaReporteContainer"></div>

        <!-- Puedes agregar aquí más contenido si es necesario -->

    </div>

    <!-- ... Código existente ... -->

    <script>
        function generarReporte() {
            // Obtener el tipo de reporte seleccionado
            var tipoReporte = document.getElementById("tipo_reporte").value;

            // Realizar una solicitud AJAX
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Actualizar el contenido del contenedor con la tabla generada
                    document.getElementById("tablaReporteContainer").innerHTML = this.responseText;
                }
            };
            // Enviar la solicitud al archivo que manejará la lógica del reporte
            xhttp.open("POST", "procesar_reporte_venta.php", true);
            xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
            xhttp.send("tipo_reporte=" + tipoReporte);
        }
    </script>

    <script>
        // Función para abrir una nueva pestaña
        function abrirNuevaPestana() {
            // URL a la que se redirigirá
            var url = "http://localhost/negocios/ferreteria_DISA/Venta/reporte/pdf.php";
            
            // Abrir una nueva pestaña
            window.open(url, '_blank');
        }
    </script>

    <!-- ... Código existente ... -->

</body>

<!-- ... Código existente ... -->

</html>
