<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Editar productos</title>
    <link rel="stylesheet" href="style_edita.css">
</head>

<body>

    <?php
    // Inicia la sesión
        session_start();

        // Verifica si el usuario ha iniciado sesión
        if (!isset($_SESSION['id_empleado'])) {
            // Si no ha iniciado sesión, redirige a la página de inicio de sesión
            header("Location: ../login.php");
            exit();
        }
    ?>

    <header>
        <div class="welcome">
            <span class="welcome-text">Bienvenido <?php echo $_SESSION['nombre_empleado'] ?></span>
            <img src="../disa png colibri.png" alt="Logo DISA" id="logo">
            <input type="submit" name="cerrar" value="Cerrar sesión" onclick="location.href='../logout.php'">
        </div>
    </header>


    <nav>
        <ul>
        <li><a href="../">Producto</a></li>
            <li><a >Venta</a></li>
        </ul>
    </nav>

    <?php

    $conexion = mysqli_connect("localhost", "root", "", "ferreteria_disa") or die("No se ha podido conectar al servidor de Base de datos");
    $conexion->set_charset("utf8");

    $registros = mysqli_query($conexion, "SELECT * FROM producto WHERE Id_producto = $_REQUEST[codEditar]") or die("Problemas en la consulta: " . mysqli_error($conexion));

    if ($reg = mysqli_fetch_array($registros)) {
        ?>
        <form method="post" action="modificar_producto.php">
            <label>Codigo del producto:<br></label>
            <input type="text" name="Id_producto" value="<?php echo $reg['Id_producto'] ?>"><br />

            <label>Nombre:<br></label>
            <input type="text" name="Nombre_pr" value="<?php echo $reg['Nombre_pr'] ?>"><br />

            <label>Precio:<br></label>
            <input type="number" name="Precio" value="<?php echo $reg['Precio'] ?>">

            <label>Cantidad:</label>
            <input type="number" name="Cantidad" value="<?php echo $reg['Cantidad'] ?>"><br />

            <label>Ubicacion:</label>
            <input type="text" name="Ubicacion" value="<?php echo $reg['Ubicacion'] ?>"><br />

            <br />
            <input type="submit" name="insert" value="Guardar">

        </form>
    <?php
    } else {
        echo "No existe el producto";
    }
    ?>
</body>

</html>
