<?php
// Conexión a la base de datos (ajusta las credenciales según tu configuración)
$usuario = "root";
$contrasena = "";
$servidor = "localhost";
$basededatos = "ferreteria_disa";

$conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se ha podido conectar al servidor de Base de datos");
$db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la base de datos");

// Obtener el tipo de reporte desde el formulario
$tipoReporte = isset($_POST['tipo_reporte']) ? $_POST['tipo_reporte'] : '';

// Variable para almacenar el contenido de la tabla
$tablaReporte = '';

// Lógica para generar la tabla según el tipo de reporte
switch ($tipoReporte) {
    case 'dia':
        // Lógica para reporte del día
        $consulta = "SELECT e.Nombre_em, p.Nombre_pr, v.Cantidad, p.Precio, v.Cantidad * p.Precio AS Subtotal, v.Fecha_hora
                     FROM venta v
                     JOIN empleado e ON v.Id_em_1 = e.Id_em
                     JOIN producto p ON v.Id_producto_1 = p.Id_producto
                     WHERE DATE(v.Fecha_hora) = CURDATE()";
        break;
    case 'ultimos7dias':
        // Lógica para reporte de los últimos 7 días
        $consulta = "SELECT e.Nombre_em, p.Nombre_pr, v.Cantidad, p.Precio, v.Cantidad * p.Precio AS Subtotal, v.Fecha_hora
                     FROM venta v
                     JOIN empleado e ON v.Id_em_1 = e.Id_em
                     JOIN producto p ON v.Id_producto_1 = p.Id_producto
                     WHERE v.Fecha_hora >= CURDATE() - INTERVAL 7 DAY";
        break;
    case 'ultimoMes':
        // Lógica para reporte del último mes
        $consulta = "SELECT e.Nombre_em, p.Nombre_pr, v.Cantidad, p.Precio, v.Cantidad * p.Precio AS Subtotal, v.Fecha_hora
                     FROM venta v
                     JOIN empleado e ON v.Id_em_1 = e.Id_em
                     JOIN producto p ON v.Id_producto_1 = p.Id_producto
                     WHERE MONTH(v.Fecha_hora) = MONTH(NOW())";
        break;
    case 'ultimoAnio':
        // Lógica para reporte del último año
        $consulta = "SELECT e.Nombre_em, p.Nombre_pr, v.Cantidad, p.Precio, v.Cantidad * p.Precio AS Subtotal, v.Fecha_hora
                     FROM venta v
                     JOIN empleado e ON v.Id_em_1 = e.Id_em
                     JOIN producto p ON v.Id_producto_1 = p.Id_producto
                     WHERE YEAR(v.Fecha_hora) = YEAR(NOW())";
        break;
    default:
        // Tipo de reporte no válido
        $tablaReporte = 'Tipo de reporte no válido.';
}

if ($tablaReporte == '') {
    // Realizar la consulta y construir la tabla
    $resultado = mysqli_query($conexion, $consulta) or die ("Algo ha ido mal en la consulta a la base de datos");

    if (mysqli_num_rows($resultado) > 0) {
        $tablaReporte .= '<table border="1">
                            <tr>
                                <th>Nombre Empleado</th>
                                <th>Nombre Producto</th>
                                <th>Cantidad</th>
                                <th>Precio Unitario (Venta)</th>
                                <th>Subtotal</th>
                                <th>Fecha y Hora</th>
                            </tr>';

        $totalVentas = 0;

        while ($fila = mysqli_fetch_assoc($resultado)) {
            $subtotal = $fila['Cantidad'] * $fila['Precio'];
            $totalVentas += $subtotal;

            $tablaReporte .= '<tr>
                                <td>' . $fila['Nombre_em'] . '</td>
                                <td>' . $fila['Nombre_pr'] . '</td>
                                <td>' . $fila['Cantidad'] . '</td>
                                <td>' . $fila['Precio'] . '</td>
                                <td>' . $subtotal . '</td>
                                <td>' . $fila['Fecha_hora'] . '</td>
                             </tr>';
        }
        
        $tablaReporte .= '<tr>
                            <td colspan="4"></td>
                            <td>Total: '  . '</td>
                            <td>' . $totalVentas . '</td>
                            <td></td>
                         </tr>';
        $tablaReporte .= '</table>';
    } else {
        $tablaReporte = 'No hay datos disponibles para el tipo de reporte seleccionado.';
    }
}

// Cerrar la conexión a la base de datos
mysqli_close($conexion);

// Devolver la tabla como respuesta
echo $tablaReporte;
?>
