<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <?php
    // Inicia la sesión
    session_start();

    // Verifica si el usuario ha iniciado sesión
    if (!isset($_SESSION['id_empleado'])) {
        // Si no ha iniciado sesión, redirige a la página de inicio de sesión
        header("Location: ../login.php");
        exit();
    }
    ?>
    
    <link rel="stylesheet" href="index.css">
</head>

<body>

    <?php
    $usuario = "root";
    $contrasena = "";
    $servidor = "localhost";
    $basededatos = "ferreteria_disa";

    $conexion = mysqli_connect($servidor, $usuario, $contrasena) or die ("No se ha podido conectar al servidor de Base de datos");

    $db = mysqli_select_db($conexion, $basededatos) or die ("Upps! Pues va a ser que no se ha podido conectar a la base de datos");

    $consulta = "SELECT * FROM producto";

    $resultado = mysqli_query($conexion, $consulta) or die ("Algo ha ido mal en la consulta a la base de datos");
    ?>

    <header>
        <div class="welcome">
            <span class="welcome-text">Bienvenido <?php echo $_SESSION['nombre_empleado'] ?></span>
            <img src="disa png colibri.png" alt="Logo DISA" id="logo">
            <input type="submit" name="cerrar" value="Cerrar sesión" onclick="location.href='logout.php'">
        </div>
    </header>

    <nav>
        <ul>
            <li><a >Producto</a></li>
            <li><a href="Venta/menu_venta.php">Venta</a></li>
        </ul>
    </nav>

    <div class="form-container">
        <br>
        <h3>Buscar productos</h3>

        <form method="POST" action="">
            <label>Nombre o código de producto:<br></label>
            <input type="text" name="busqueda" placeholder="Escriba el código del producto"><br />
            <br />
            <input type="submit" name="buscar" value="Buscar">
            <input type="submit" name="Registrar" value="Registrar" formaction="Productos/registrar_producto.php">
            <input type="submit" name="faltante" value="Faltante" onclick="abrirNuevaPestana()">
            <input type="submit" name="volver" value="Volver" formaction="../index.php">
        </form>
    </div>

    <?php

    if (isset($_POST["buscar"])) {
        $busqueda = $_POST["busqueda"];

        $buscar = "SELECT * FROM producto WHERE Id_producto LIKE '%$busqueda%' OR Nombre_pr LIKE '%$busqueda%'";

        $resultado = mysqli_query($conexion, $buscar) or die ("Error al buscar los registros");

        mysqli_close($conexion);

        if (mysqli_num_rows($resultado) == 0) {
            echo "No se encontraron resultados";
        } else {
            echo "<table borde=2>";
            echo "<tr>";
            echo "<th>Código </th>";
            echo "<th>Nombre</th>";
            echo "<th>Precio de distribuidor</th>";
            echo "<th>Precio de venta</th>";
            echo "<th>Cantidad</th>";
            echo "<th>Ubicación</th>";
            echo "<th>Eliminar</th>";
            echo "<th>Modificar</th>";
            echo "</tr>";

            while ($columna = mysqli_fetch_array($resultado)) {
                echo "<tr>";
                echo "<td>" . $columna['Id_producto'] . "</td><td>" . $columna['Nombre_pr'] . "</td><td>" . $columna['Precio_dis'] . "</td><td>" . $columna['Precio'] . "</td><td>" . $columna['Cantidad'] . "</td>" . "</td><td>" . $columna['Ubicacion'] . "</td>";
                echo "<td>
                        <form method ='POST' action = 'Productos/eliminar_producto.php'> <input type ='hidden' value='$columna[Id_producto]' name='codEliminar' /> <input type='submit' value='Eliminar' /> </form> </td>";
                echo "<td>
                        <form method ='POST' action = 'Productos/editar_producto.php'> <input type ='hidden' value='$columna[Id_producto]' name='codEditar' /> <input type='submit' value='Modificar' /> </form> </td>";
                echo "</tr>";
            }
        }

    }

    
    

    ?>

    <script>
        // Función para abrir una nueva pestaña
        function abrirNuevaPestana() {
            // URL a la que se redirigirá
            var url = "http://localhost/negocios/ferreteria_DISA/Productos/reporte/pdf.php";
            
            // Abrir una nueva pestaña
            window.open(url, '_blank');
        }
    </script>


    <footer>
        <!-- Contenido del pie de página -->
    </footer>

</body>

</html>
