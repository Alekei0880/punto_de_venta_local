<!DOCTYPE html>

<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Modificar producto</title>
    <link rel="stylesheet" href="style_menu.css">
</head>

<body>

    <?php
    // Inicia la sesión
        session_start();

        // Verifica si el usuario ha iniciado sesión
        if (!isset($_SESSION['id_empleado'])) {
            // Si no ha iniciado sesión, redirige a la página de inicio de sesión
            header("Location: ../login.php");
            exit();
        }
        ?>

    <div>
        <input type="submit" name="volver" value="Volver" onclick="location.href='../index.php'">
    </div>

    <?php
    $conexion = mysqli_connect("localhost", "root", "", "ferreteria_disa") or die("No se ha podido conectar al servidor de Base de datos");
    $conexion->set_charset("utf8");

    if (isset($_REQUEST['Id_producto'])) {

        $Id_producto = $_REQUEST['Id_producto'];
        $Nombre_pr = $_REQUEST['Nombre_pr'];
        $Precio = $_REQUEST['Precio'];
        $Cantidad = $_REQUEST['Cantidad'];
        $Ubicacion = $_REQUEST['Ubicacion'];

        $sql = "UPDATE producto SET Nombre_pr = '$Nombre_pr', Precio = '$Precio', Cantidad = '$Cantidad', Ubicacion= '$Ubicacion' WHERE Id_producto = '$Id_producto'";

        $resultado = mysqli_query($conexion, $sql);

        if ($resultado) {
            //funcion para volver a la pagina anterior y oprime el boton buscar

            header("Location: ../index.php");

            

        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conexion);
        }
    } else {
        echo "No se ha recibido ningún dato";
    }
    ?>
</body>

</html>
