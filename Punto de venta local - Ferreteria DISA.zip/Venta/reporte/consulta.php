<?php
require('conexion.php');
$sql = "SELECT e.Nombre_em, p.Nombre_pr, v.Cantidad, p.Precio, v.Cantidad * p.Precio AS Subtotal, v.Fecha_hora
        FROM venta v
        JOIN empleado e ON v.Id_em_1 = e.Id_em
        JOIN producto p ON v.Id_producto_1 = p.Id_producto
        WHERE DATE(v.Fecha_hora) = CURDATE()";
$stmt = $conexion->prepare($sql);
$result = $stmt->execute();
$rows = $stmt->fetchAll(\PDO::FETCH_ASSOC);
$total = 0; // Variable para almacenar la suma de los subtotales

foreach ($rows as $row) {
    $subtotal = $row['Cantidad'] * $row['Precio']; // Calcula el subtotal

    // Imprime una fila de la tabla por cada registro de la consulta
    print $row['Nombre_em'] . ";" . $row['Nombre_pr'] . ";" . $row['Cantidad'] . ";" . $row['Precio'] . ";" . $subtotal . ";" . $row['Fecha_hora'] . "\n";

    // Agrega el subtotal al total
    $total += $subtotal;
}


?>
